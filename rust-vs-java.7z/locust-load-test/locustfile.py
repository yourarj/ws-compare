import time
from locust import HttpUser, task, constant_pacing

class QuickstartUser(HttpUser):
    wait_time = constant_pacing(0.1)

    @task
    def hello_world(self):
        self.client.get("/fibonacci/30")