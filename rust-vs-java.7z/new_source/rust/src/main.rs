mod app;
#[actix_web::main]
async fn main() -> Result<(), std::io::Error>{
    app::start().await
}
