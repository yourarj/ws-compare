use actix_web::{HttpServer, App, web};

mod hello;
mod greet;
mod fibonacci;

pub async fn start() -> Result<(), std::io::Error>{
    let bind_address = "0.0.0.0:8080";
    HttpServer::new(|| {
        App::new().configure(routes)
        })
        .bind(&bind_address)
        .unwrap_or_else(|_| panic!("Could not bind server to address {}", &bind_address))
        .run()
        .await
}

fn routes(app: &mut web::ServiceConfig) {
    app
        .route("/hello", web::get().to(hello::get))
        .route("/greeting/{name}", web::get().to(greet::get))
        .route("/fibonacci/{input}", web::get().to(fibonacci::get));
}

