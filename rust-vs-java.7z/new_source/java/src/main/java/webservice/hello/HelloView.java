package webservice.hello;

public class HelloView {
    public final String message;

    HelloView(String message) {
        this.message = message;
    }
}
