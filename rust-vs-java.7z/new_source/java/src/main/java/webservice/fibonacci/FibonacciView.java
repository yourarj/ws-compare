package webservice.fibonacci;

public class FibonacciView {
    public final long input;
    public final long output;

    public FibonacciView(long input, long output) {
        this.input = input;
        this.output = output;
    }
}
